// function price (){
//     function sction_a(){
//         alert("50000");
//     }

//         function sction_B(){
//             alert("70000"); 
//         }

//         function sction_C(){
//           alert("80000");
//       }
//     return(
//         <>
        
//         <div style={{width:"100%" }} >
//         <div className="container">
//             <br />
//             <center><h1>price</h1></center>
//             <br />
//             <div>
//               <h2>AS Banquet</h2>
//               <br />
//             </div>

//       <div className="row">
//                 <div className="col-sm-3 mb-4">
//           <div className="card">
//             <img src="https://www.imperialpalacebanquethall.com/wp-content/uploads/2018/08/NWX_3528.jpg" className="card-img-top" alt="Card 2" />
//             <div className="card-body">
//               <h5 className="card-title">Section A</h5>
//               <p className="card-text">Short description here.</p>
//               {/* <a href="#" >Action</a> */}
//               <button onClick={sction_a} className="btn btn-primary">Price</button>
//             </div>
//           </div>
//         </div>
        
    
//                 <div className="col-sm-3 mb-4">
//           <div className="card">
//             <img src="https://royalpepper.in/images/banquet/banquet-halls-in-peeragarhi-halls-peeragarhi.jpg" className="card-img-top" alt="Card 2" />
//             <div className="card-body">
//               <h5 className="card-title">Section B</h5>
//               <p className="card-text">Short description here.</p>
//               {/* <a href="#" className="btn btn-primary">Action</a> */}
//               <button onClick={sction_B} className="btn btn-primary">Price</button>

//             </div>
//           </div>
//         </div>
        
    
//                 <div className="col-sm-3 mb-4">
//           <div className="card">
//             <img src="https://www.oyorooms.com/blog/wp-content/uploads/2018/02/fe-2.png" className="card-img-top" alt="Card 2" />
//             <div className="card-body">
//               <h5 className="card-title">Section C</h5>
//               <p className="card-text">Short description here.</p>
//               {/* <a href="#" className="btn btn-primary">Action</a> */}
//               <button onClick={sction_C} className="btn btn-primary">Price</button>
//             </div>
            
//           </div>
//         </div>
//      </div>

//       </div>
//     </div>
//     <br/> <br/>
        
//         </>
//     )
// }
// export default price;