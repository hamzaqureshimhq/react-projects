// function Events (){
// function pro(){
//     var num1 = parseFloat(prompt("Enter English"));
//     var num2 = parseFloat(prompt("Enter Math Number"));
//     var num3 = parseFloat(prompt("Enter Urdu Number"));

//      var add = num1 + num2 + num3;
//      var Persentage = (add * 100) / 300; 
//      console.log("English:" + num1 + "Math " + num2 + "Urdu " + num3)
//      console.log("Total:" + add)
//      console.log("Persentage" + Persentage)
     

// }
    
// return(
//     <>
//     <div className="col-sm-3 mb-4">
//           <div className="card">
//             <img src="https://www.oyorooms.com/blog/wp-content/uploads/2018/02/fe-2.png" className="card-img-top" alt="Card 2" />
//             <div className="card-body">
//               <h5 className="card-title">Section C</h5>
//               <p className="card-text">Short description here.</p>
//               {/* <a href="#" className="btn btn-primary">Action</a> */}
//               <button onClick={pro} className="btn btn-primary">Price</button>
//             </div>
            
//           </div>
//         </div>
//     </>
// )


// }

// export default Events;
     













//     // function sction_a(){
//     //     alert("50000");
//     // }

//     //     function sction_B(){
//     //         alert("70000");
//     //     }

//     //     function sction_C(){
//     //       alert("80000");
//     //   }
  